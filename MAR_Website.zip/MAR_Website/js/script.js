// --- 1. Stats Counter Animation ---
const counters = document.querySelectorAll('.counter');
const speed = 200;

counters.forEach(counter => {
    const updateCount = () => {
        const target = +counter.getAttribute('data-target');
        const count = +counter.innerText.replace('+', '');
        const inc = target / speed;

        if (count < target) {
            counter.innerText = Math.ceil(count + inc) + "+";
            setTimeout(updateCount, 20);
        } else {
            counter.innerText = target + "+";
        }
    };
    updateCount();
});

// --- 2. Projects Data & Rendering (Images from assets/projects/) ---
const projects = [
    { 
        name: "Popeyes, International City", 
        client: "MARISTO INTERIOR DESIGN LLC", 
        desc: "FCU-04, FAHU-01 and Ecology Unit-01 ducting, chilled water pipes, diffusers, electrical connections and kitchen hood installation.", 
        val: 101000, status: "o", start: "20 Apr 2026", end: "30 Jul 2026", dur: 70, prog: 65,
        img: "assets/projects/project1.jpeg" // <--- এখানে আপনার ছবির নাম দিন
    },
    { 
        name: "Dubai Mall Expansion", 
        client: "Al Futtaim Engineering", 
        desc: "Complete chilled water pipe installation and valve packages for the new food court area.", 
        val: 250000, status: "d", start: "10 Jan 2026", end: "15 Mar 2026", dur: 63, prog: 100,
        img: "assets/projects/project2.jpg" // <--- এখানে আপনার ছবির নাম দিন
    },
    { 
        name: "Downtown Dubai Tower", 
        client: "Emaar Properties", 
        desc: "GI Duct installation with 25mm thick rockwool insulation and fire-rated gaskets.", 
        val: 180000, status: "u", start: "01 Aug 2026", end: "30 Oct 2026", dur: 90, prog: 0,
        img: "assets/projects/project3.jpg" // <--- এখানে আপনার ছবির নাম দিন
    }
];

const statusMap = {
    o: { text: "Ongoing", class: "s-o" },
    u: { text: "Upcoming", class: "s-u" },
    d: { text: "Completed", class: "s-d" }
};

function renderProjects(filter = 'all') {
    const grid = document.getElementById('projectGrid');
    const filtered = projects.filter(p => filter === 'all' || p.status === filter);

    grid.innerHTML = filtered.map(p => `
        <article class="project-card">
            <div class="project-img-wrap">
                <img src="${p.img}" alt="${p.name}">
            </div>
            <div class="project-details">
                <div>
                    <span class="status-badge ${statusMap[p.status].class}">${statusMap[p.status].text}</span>
                    <h3>${p.name}</h3>
                    <span class="client">${p.client}</span>
                    <p class="desc">${p.desc}</p>
                </div>
                <dl>
                    <dt>Contract value (ex VAT)</dt>
                    <dd>AED ${p.val.toLocaleString()}</dd>
                    <dt>Start date</dt>
                    <dd>${p.start}</dd>
                    <dt>Duration</dt>
                    <dd>${p.dur} days</dd>
                </dl>
                <dl>
                    <dt>${p.status === 'd' ? 'Handed over' : 'Handover due'}</dt>
                    <dd>${p.end}</dd>
                    <div class="progress-wrap">
                        <div class="progress-text">
                            <span>Progress</span>
                            <span>${p.prog}%</span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: ${p.prog}%;"></div>
                        </div>
                    </div>
                </dl>
            </div>
        </article>
    `).join('');
}

function filterProjects(status) {
    document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    renderProjects(status);
}

renderProjects();

// --- 3. Employee Modal Logic (Images from assets/team/) ---
const employees = [
    {
        name: "Md. Rakib Hosen", role: "Managing Director",
        img: "assets/team/team1.jpg", // <--- এখানে আপনার ছবির নাম দিন
        exp: "12+ Years", skills: "Business Strategy, Client Relations, Contracts",
        email: "azimrakibuae786@gmail.com", phone: "+971 50 163 4587"
    },
    {
        name: "Md. Karim", role: "HVAC Engineer",
        img: "assets/team/team2.jpg", // <--- এখানে আপনার ছবির নাম দিন
        exp: "8+ Years", skills: "Chilled Water Design, Duct Layouts, Load Checks",
        email: "karim@marresource.com", phone: "+971 50 111 2222"
    },
    {
        name: "Mr. Sujon", role: "Site Supervisor",
        img: "assets/team/team3.jpg", // <--- এখানে আপনার ছবির নাম দিন
        exp: "6+ Years", skills: "Duct & Pipe Installation, Quality Control, Safety",
        email: "sujon@marresource.com", phone: "+971 50 333 4444"
    }
];

const modal = document.getElementById('employeeModal');

function openModal(index) {
    const emp = employees[index];
    document.getElementById('modalImg').src = emp.img;
    document.getElementById('modalName').textContent = emp.name;
    document.getElementById('modalRole').textContent = emp.role;
    document.getElementById('modalExp').textContent = emp.exp;
    document.getElementById('modalSkills').textContent = emp.skills;
    document.getElementById('modalEmail').textContent = emp.email;
    document.getElementById('modalPhone').textContent = emp.phone;
    
    modal.classList.add('active');
}

function closeModal() {
    modal.classList.remove('active');
}

window.onclick = function(event) {
    if (event.target === modal) {
        closeModal();
    }
}

// --- 4. Theme Toggle Logic ---
const themeBtn = document.getElementById('themeToggle');
const themeIcon = themeBtn.querySelector('i');

const currentTheme = localStorage.getItem('theme');
if (currentTheme === 'light') {
    document.documentElement.setAttribute('data-theme', 'light');
    themeIcon.classList.replace('fa-moon', 'fa-sun');
}

themeBtn.addEventListener('click', () => {
    if (document.documentElement.getAttribute('data-theme') === 'light') {
        document.documentElement.removeAttribute('data-theme');
        localStorage.setItem('theme', 'dark');
        themeIcon.classList.replace('fa-sun', 'fa-moon');
    } else {
        document.documentElement.setAttribute('data-theme', 'light');
        localStorage.setItem('theme', 'light');
        themeIcon.classList.replace('fa-moon', 'fa-sun');
    }
});

// --- 5. Smooth Scrolling ---
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if(target){
            target.scrollIntoView({ behavior: 'smooth' });
        }
    });
});